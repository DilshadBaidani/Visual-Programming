﻿namespace Student_Information
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Std_name = new System.Windows.Forms.TextBox();
            this.city = new System.Windows.Forms.TextBox();
            this.phone_no = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.std_last_name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.add_std = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.show_std_info = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Std_name
            // 
            this.Std_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Std_name.Location = new System.Drawing.Point(214, 69);
            this.Std_name.Name = "Std_name";
            this.Std_name.Size = new System.Drawing.Size(204, 29);
            this.Std_name.TabIndex = 0;
            // 
            // city
            // 
            this.city.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.city.Location = new System.Drawing.Point(214, 261);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(204, 29);
            this.city.TabIndex = 1;
            // 
            // phone_no
            // 
            this.phone_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone_no.Location = new System.Drawing.Point(214, 325);
            this.phone_no.Name = "phone_no";
            this.phone_no.Size = new System.Drawing.Size(204, 29);
            this.phone_no.TabIndex = 2;
            // 
            // Address
            // 
            this.Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address.Location = new System.Drawing.Point(214, 197);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(204, 29);
            this.Address.TabIndex = 3;
            // 
            // std_last_name
            // 
            this.std_last_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.std_last_name.Location = new System.Drawing.Point(214, 133);
            this.std_last_name.Name = "std_last_name";
            this.std_last_name.Size = new System.Drawing.Size(204, 29);
            this.std_last_name.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Student Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Student Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(109, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(124, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "City";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(86, 329);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Mobile Number";
            // 
            // add_std
            // 
            this.add_std.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.add_std.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_std.Location = new System.Drawing.Point(132, 388);
            this.add_std.Name = "add_std";
            this.add_std.Size = new System.Drawing.Size(108, 40);
            this.add_std.TabIndex = 10;
            this.add_std.Text = "Add";
            this.add_std.UseVisualStyleBackColor = false;
            this.add_std.Click += new System.EventHandler(this.add_std_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(288, 388);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(108, 40);
            this.clear.TabIndex = 11;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // show_std_info
            // 
            this.show_std_info.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.show_std_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_std_info.Location = new System.Drawing.Point(132, 445);
            this.show_std_info.Name = "show_std_info";
            this.show_std_info.Size = new System.Drawing.Size(264, 40);
            this.show_std_info.TabIndex = 12;
            this.show_std_info.Text = "Show Student Info";
            this.show_std_info.UseVisualStyleBackColor = false;
            this.show_std_info.Click += new System.EventHandler(this.show_std_info_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 516);
            this.Controls.Add(this.show_std_info);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.add_std);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.std_last_name);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.phone_no);
            this.Controls.Add(this.city);
            this.Controls.Add(this.Std_name);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Std_name;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.TextBox phone_no;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox std_last_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button add_std;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button show_std_info;
    }
}

